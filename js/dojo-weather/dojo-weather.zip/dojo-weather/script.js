function alertReport(city) {
    alert("Loading weather report for " + city.innerText + "...");
}

function removeCookie() {
    document.querySelector(".cookie-container").remove();
}

function convertTemp(high, low) {
    var nodeListHigh = document.querySelectorAll(high);
    var nodeListLow = document.querySelectorAll(low);
    var newListHigh = []; // could use two-d array
    var newListLow = [];
    var unit = checkUnit();

    if (unit == "farenheit") {
        for (var i = 0; i < nodeListHigh.length; i++) {
            newListHigh.push(Math.round((nodeListHigh[i].innerText) * 9/5 + 32));
            newListLow.push(Math.round((nodeListLow[i].innerText) * 9/5 + 32));
        }

    } else {
        for (var i = 0; i < nodeListHigh.length; i++) {
            newListHigh.push(Math.round(((nodeListHigh[i].innerText) - 32) * 5/9));
            newListLow.push(Math.round(((nodeListLow[i].innerText) - 32) * 5/9));
        }
    }

    for (var i = 0; i < nodeListHigh.length; i++) {
        nodeListHigh[i].innerText = newListHigh[i];
        nodeListLow[i].innerText = newListLow[i];
    }
}

function checkUnit() {
    return document.querySelector("#toggle-temperature").value;
}



