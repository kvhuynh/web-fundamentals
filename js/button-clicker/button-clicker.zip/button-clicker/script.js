function toggleLogin(element) {
    element.innerText = "Logout";
}

function removeDef(element) {
    element.remove();
}

function wasLiked(element) {
    console.log(element)
    alert("Ninja was liked");
}